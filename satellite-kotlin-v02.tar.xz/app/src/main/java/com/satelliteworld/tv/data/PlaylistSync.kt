package com.satelliteworld.tv.data

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.FilterInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

object PlaylistSync {
    const val TV_SOURCE = "github:iptv-org-country"
    const val RADIO_SOURCE = "github:verified-radio"

    const val TV_URL = "https://iptv-org.github.io/iptv/index.country.m3u"
    const val RADIO_URL = "https://raw.githubusercontent.com/eyalev/verified-radio-streams/main/m3u/all.m3u"

    data class SyncResult(val tv: Int, val radio: Int, val messages: List<String>)

    fun sync(context: Context, onUpdate: (String) -> Unit = {}): SyncResult {
        val db = ReceiverDatabase(context)
        var tv = 0
        var radio = 0
        val messages = mutableListOf<String>()
        for ((source, url, isRadio) in listOf(
            Triple(TV_SOURCE, TV_URL, false), Triple(RADIO_SOURCE, RADIO_URL, true)
        )) {
            try {
                onUpdate(if (isRadio) "جاري تنزيل محطات الراديو..." else "جاري تنزيل القنوات...")
                val channels = fetch(url, source, isRadio)
                val minimum = if (isRadio) 50 else 100
                if (channels.size < minimum) throw IllegalStateException("Short playlist: ${channels.size} (minimum $minimum)")
                val imported = db.replaceSource(source, channels)
                if (isRadio) radio = imported else tv = imported
                messages += "${if (isRadio) "Radio" else "TV"}: $imported imported"
            } catch (e: Exception) {
                messages += "${if (isRadio) "Radio" else "TV"}: ${e.message ?: "Network error"}; cached list retained"
            }
        }
        db.setPreference("last_sync", System.currentTimeMillis().toString())
        db.close()
        return SyncResult(tv, radio, messages)
    }

    private fun fetch(link: String, source: String, isRadio: Boolean): List<ChannelEntry> {
        val conn = URL(link).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 45000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "SatelliteWorldTV/0.1 (Android; GitHub directory consumer)")
        try {
            if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
            val limited = object : FilterInputStream(conn.inputStream) {
                var readBytes = 0L
                override fun read(): Int {
                    val n = super.read()
                    if (n >= 0 && ++readBytes > 25_000_000L) throw IOException("Playlist size limit exceeded")
                    return n
                }
                override fun read(buffer: ByteArray, off: Int, len: Int): Int {
                    val n = super.read(buffer, off, len)
                    if (n > 0) {
                        readBytes += n
                        if (readBytes > 25_000_000L) throw IOException("Playlist size limit exceeded")
                    }
                    return n
                }
            }
            BufferedReader(InputStreamReader(limited, StandardCharsets.UTF_8)).use { reader ->
                return PlaylistParser.parse(reader, source, isRadio)
            }
        } finally { conn.disconnect() }
    }
}
